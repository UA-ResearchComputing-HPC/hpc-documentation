#!/usr/bin/env Rscript

hello_string <- "Hello World! "
print (hello_string, quote=FALSE)
